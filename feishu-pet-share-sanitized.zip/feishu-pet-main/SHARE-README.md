# Feishu Pet 分享版

这是已脱敏的分享版本：不包含本机的 LLM 配置、API Key、飞书登录态、`.env.local`、`node_modules`、构建缓存或日志。

## 启动

需要 macOS、Node.js 和 npm：

```bash
npm install
npm run pet
```

启动后，右键桌面宠物可以切换 Fanux、Tiana、Yaobii、Bearix、Ruby、Carson 等皮肤。

## 大模型

如需使用大模型，请在应用的“大模型设置”中填写你自己的配置；分享包不会携带任何 API Key。也可以使用本机已登录的 Codex CLI 或 Claude Code CLI。

## 飞书功能

飞书工作台和消息监工需要每位使用者自行安装并登录 `lark-cli`，并按应用提示完成权限授权。包内只有示例配置，不含任何个人账号信息。
